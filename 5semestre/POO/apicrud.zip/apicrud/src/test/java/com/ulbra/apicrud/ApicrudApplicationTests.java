package com.ulbra.apicrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApicrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
